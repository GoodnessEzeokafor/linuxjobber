from django.apps import AppConfig


class Gootech442ScrumyConfig(AppConfig):
    name = 'gootech442scrumy'
