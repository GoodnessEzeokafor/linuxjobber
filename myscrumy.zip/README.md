# LINUXJOBBER INTERNSHIP CHALLANGE
LinuxJobber
=============
## DESCRIPTION
App built during linuxjobber internship

### PREREQUISITE
Make sure u have django(2.0.6), pipenv intalled on your system
### Procedure
### Simply clone this repo
    $ git clone [repo link]
    $ cd project_name
    $ pipenv shell
    $ pipenv install
    $ python manage.py runserver

change the python_version to your system version in your Pipfile

## Technology Used
* Backend 
    * Django/Python
    * SQLITE
* Frontend
    * HTML/CSS
    * Bootstrap
    * Javascript
    * Angular

<p>  </p>

## Contributors
* Goodness Ezeokafor : gootech442@gmail.com

# Happy Hacking!!
